//
//  EditLibraryViewWithSwiftData.swift
//  QQ
//
//  Created by 구민규 on 5/12/24.
//

import SwiftUI
import SwiftData
struct EditLibraryViewWithSwiftData: View {
    @Bindable var questionData:QuestionData
    var body: some View {
        NavigationStack{
            Form{
                TextField("제목",text:$questionData.name)
                HStack{
                    TextField("카테고리",text:$questionData.category)
                    DatePicker("", selection: $questionData.date,displayedComponents: .date)
                }
                Section(header:Text("문제")){
                    TextField("",text:$questionData.question)
                    Picker("",selection: $questionData.answer){
                        Text("ㅇ").tag("ㅇ")
                        Text("x").tag("x")
                        
                    }.pickerStyle(.palette)
                    
                }
                
            }
            .navigationTitle("수정")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    do{
        let config = ModelConfiguration(isStoredInMemoryOnly: true)
        let container = try ModelContainer(for: QuestionData.self, configurations: config)
        let example = QuestionData(name:"한국사 1주차 시험",question: "6.25전쟁이 일어난 시기는 1950년이다.",date:.now , answer: "ㅇ" , category:"한국사")
        return EditLibraryViewWithSwiftData(questionData: example)
        .modelContainer(container)}
    catch{
        fatalError("fail to load")
    }
    
    
}
//do catch 문을 반드시 이용해야한다.
