//
//  LibraryComponent.swift
//  QQ
//
//  Created by 구민규 on 5/10/24.
//

import SwiftUI

struct LibraryComponent: View {
    var body: some View {
        
        HStack(spacing:18){
            RoundedRectangle(cornerRadius: 24)
                .fill(Color("color1"))
                .frame(width:72,height:72)
            
            VStack(alignment:.leading){
                Text("AI 활용표현과 문제해결").font(.system(size: 18).bold())
                Text("2023-04-23").font(.system(size: 14))
                    .fontWeight(.semibold)
                    .foregroundColor(.gray)
                
            }}
        
        .padding(20)
        .frame(width:400)
            .background(Color.blue) // Set the background color
            .clipShape(RoundedRectangle(cornerRadius: 30)) // Clip the shape with rounded corners
    }
}

#Preview {
    LibraryComponent()
}
