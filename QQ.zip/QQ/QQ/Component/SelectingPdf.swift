//
//  SelectingPdf.swift
//  QQ
//
//  Created by 구민규 on 5/10/24.
//


import SwiftUI
import UniformTypeIdentifiers

struct DocumentPicker: UIViewControllerRepresentable {
    @Binding var selectedPDF: URL?

    class Coordinator: NSObject, UINavigationControllerDelegate, UIDocumentPickerDelegate {
        var parent: DocumentPicker

        init(parent: DocumentPicker) {
            self.parent = parent
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let selectedURL = urls.first else { return }
            parent.selectedPDF = selectedURL
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.pdf], asCopy: true)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
}


struct SelectingPdf: View {
    @State private var isDocumentPickerPresented = false
    @State private var selectedPDF: URL?

    var body: some View {
        VStack {
            if let pdfURL = selectedPDF {
                Text("선택된 PDF: \(pdfURL.lastPathComponent)")
            } else {
                Text("PDF를 선택하세요")
            }

            Button(action: {
                isDocumentPickerPresented = true
            }) {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(lineWidth: 0.5)
                    .frame(height: 60)
                    .overlay(
                        Text("PDF 선택")
                            .font(.system(size: 18))
                            .fontWeight(.bold)
                    )
            }
            .sheet(isPresented: $isDocumentPickerPresented) {
                DocumentPicker(selectedPDF: $selectedPDF)
            }
        }
        .padding()
    }
}

#Preview {
    SelectingPdf()
}
