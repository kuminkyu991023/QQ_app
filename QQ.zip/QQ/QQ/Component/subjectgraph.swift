//
//  subjectgraph.swift
//  QQ
//
//  Created by 구민규 on 5/9/24.
//

import SwiftUI
import Charts

struct subject:Identifiable{
    let id = UUID()
    var x = ""
    var y = 0
    
    static func fetchData() ->[subject]{
        [
        subject(x:"토익",y:5),
        subject(x:"일본문화",y:10),
        subject(x:"동남아역사",y:15),
        subject(x:"역사와 리더쉽",y:12),
        subject(x:"컴퓨터구조",y:21)]
        
    }
    
}


struct subjectgraph: View {
    @State private var plots = subject.fetchData()
    
    var body: some View {
        Chart(plots) {
            plot in
            BarMark(x: .value("",plot.x), y: .value("",plot.y))
        }.padding(16)
    }
}

#Preview {
    subjectgraph()
}
