//
//  dailycountergraph.swift
//  QQ
//
//  Created by 구민규 on 5/9/24.
//

import SwiftUI
import Charts

struct countingSoleQuestion:Identifiable{
    let id = UUID()
    var x = ""
    var y = 0
    
    static func fetchData() ->[subject]{
        [
        subject(x:"월",y:30),
        subject(x:"화",y:40),
        subject(x:"수",y:20),
        subject(x:"목",y:60),
        subject(x:"금",y:35),
        subject(x:"토",y:35),
        subject(x:"일",y:10),
        
        ]
        
    }
    
}



struct dailycountergraph: View {
    @State private var plots = countingSoleQuestion.fetchData()
    var body: some View {
        Chart(plots){
            plot in LineMark(x: .value("", plot.x), y: .value("", plot.y))
                .lineStyle(StrokeStyle(lineWidth: 4,lineJoin: CGLineJoin.round))
        }
        .padding(.horizontal,16)
    }
}

#Preview {
    dailycountergraph()
}
