//
//  shortsView.swift
//  QQ
//
//  Created by 구민규 on 5/11/24.
//

import SwiftUI

struct shortsView: View {
    @State var index = 0
    @State var showAlert = false
    @State var alertMessage = ""
    
    @State var data = [
        TextContent(id: 0, question: "Generative Adversarial Networks (GAN)의 주요 구성 요소는 무엇인가요?", answer1: "Generator와 Classifier", answer2: "Generator와 Discriminator", answer3: "Generator와 Encoder", answer4: "Discriminator와 Decoder", correct: "Generator와 Discriminator"),
        TextContent(id: 1, question: "GAN의 주요 목적은 무엇인가요?", answer1: "데이터를 분류하는 것", answer2: "새로운 데이터를 생성하는 것", answer3: "데이터를 압축하는 것", answer4: "데이터를 군집화하는 것", correct: "새로운 데이터를 생성하는 것"),
        TextContent(id: 2, question: "CycleGAN의 주요 기능은 무엇인가요?", answer1: "이미지를 분류하는 것", answer2: "이미지를 고해상도로 변환하는 것", answer3: "도메인 간 이미지 변환을 수행하는 것", answer4: "텍스트 데이터를 이미지로 변환하는 것", correct: "도메인 간 이미지 변환을 수행하는 것"),
        TextContent(id: 3, question: "비지도 학습에서 사용하는 데이터는 무엇인가요?", answer1: "레이블이 있는 데이터", answer2: "레이블이 없는 데이터", answer3: "부분적으로 레이블이 있는 데이터", answer4: "생성된 데이터", correct: "레이블이 없는 데이터"),
        TextContent(id: 4, question: "GAN 학습 과정에서 Generator의 역할은 무엇인가요?", answer1: "진짜 데이터를 분류하는 것", answer2: "진짜 데이터를 생성하는 것", answer3: "가짜 데이터를 생성하는 것", answer4: "가짜 데이터를 분류하는 것", correct: "가짜 데이터를 생성하는 것"),
        TextContent(id: 5, question: "Super Resolution GAN (SRGAN)은 어떤 문제를 해결하기 위한 기법인가요?", answer1: "이미지 분류", answer2: "이미지 생성", answer3: "저해상도 이미지를 고해상도로 변환", answer4: "도메인 적응", correct: "저해상도 이미지를 고해상도로 변환"),
        TextContent(id: 6, question: "StyleGAN의 주요 목적은 무엇인가요?", answer1: "고해상도 이미지를 저해상도로 변환하는 것", answer2: "다양한 스타일의 이미지를 생성하는 것", answer3: "텍스트 데이터를 생성하는 것", answer4: "비디오 데이터를 생성하는 것", correct: "다양한 스타일의 이미지를 생성하는 것"),
        TextContent(id: 7, question: "GAN에서 Discriminator의 역할은 무엇인가요?", answer1: "데이터를 생성하는 것", answer2: "진짜와 가짜 데이터를 구별하는 것", answer3: "데이터를 압축하는 것", answer4: "데이터를 군집화하는 것", correct: "진짜와 가짜 데이터를 구별하는 것"),
        TextContent(id: 8, question: "Generative 모델의 주요 목표는 무엇인가요?", answer1: "데이터를 분류하는 것", answer2: "데이터를 생성하는 것", answer3: "데이터를 압축하는 것", answer4: "데이터를 군집화하는 것", correct: "데이터를 생성하는 것"),
        TextContent(id: 9, question: "GAN에서 Discriminator의 학습 목표는 무엇인가요?", answer1: "진짜 데이터와 가짜 데이터를 완벽히 구별하는 것", answer2: "진짜 데이터를 생성하는 것", answer3: "가짜 데이터를 생성하는 것", answer4: "진짜 데이터를 분류하는 것", correct: "진짜 데이터와 가짜 데이터를 완벽히 구별하는 것")
    ]

    var body: some View {
        ZStack {
            TextScrollView(data: self.$data, showAlert: self.$showAlert, alertMessage: self.$alertMessage)
            
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    VStack(spacing: 35) {
                        Button(action: {}) {
                            VStack(spacing: 8) {
                                // Image(systemName: "heart.fill")
                                // .font(.title)
                                // .foregroundColor(.white)
                                // Text("22K")
                                // .foregroundColor(.white)
                            }
                        }
                        Button(action: {}) {
                            VStack(spacing: 8) {
                                // Image(systemName: "message.fill")
                                // .font(.title)
                                // .foregroundColor(.white)
                                // Text("1021")
                                // .foregroundColor(.white)
                            }
                        }
                        Button(action: {}) {
                            VStack(spacing: 8) {
                                // Image(systemName: "arrowshape.turn.up.right.fill")
                                // .font(.title)
                                // .foregroundColor(.white)
                                // Text("Share")
                                // .foregroundColor(.white)
                            }
                        }
                    }
                    .padding(.bottom, 55)
                    .padding(.trailing)
                }
            }
            .padding(.top, UIApplication.shared.windows.first?.safeAreaInsets.top)
            .padding(.bottom, (UIApplication.shared.windows.first?.safeAreaInsets.bottom)! + 5)
        }
        .background(Color.black.edgesIgnoringSafeArea(.all))
        .edgesIgnoringSafeArea(.all)
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Result"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}

struct TextContent: Identifiable {
    var id: Int
    var question: String
    var answer1: String
    var answer2: String
    var answer3: String
    var answer4: String
    var correct: String
}

struct TextScrollView: UIViewRepresentable {
    @Binding var data: [TextContent]
    @Binding var showAlert: Bool
    @Binding var alertMessage: String

    func makeCoordinator() -> Coordinator {
        return TextScrollView.Coordinator(parent: self)
    }

    func makeUIView(context: Context) -> UIScrollView {
        let view = UIScrollView()
        let childView = UIHostingController(rootView: TextView(data: self.$data, showAlert: self.$showAlert, alertMessage: self.$alertMessage))
        
        childView.view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * CGFloat(data.count))
        view.contentSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * CGFloat(data.count))
        
        view.addSubview(childView.view)
        view.showsVerticalScrollIndicator = false
        view.showsHorizontalScrollIndicator = false
        view.contentInsetAdjustmentBehavior = .never
        view.isPagingEnabled = true
        view.delegate = context.coordinator
        
        return view
    }

    func updateUIView(_ uiView: UIScrollView, context: Context) {
        uiView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * CGFloat(data.count))
        
        for i in 0..<uiView.subviews.count {
            uiView.subviews[i].frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height * CGFloat(data.count))
        }
    }

    class Coordinator: NSObject, UIScrollViewDelegate {
        var parent: TextScrollView
        var index = 0

        init(parent: TextScrollView) {
            self.parent = parent
        }

        func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
            let currentIndex = Int(scrollView.contentOffset.y / UIScreen.main.bounds.height)
            
            if index != currentIndex {
                index = currentIndex
                // Additional actions when a new text is displayed
            }
        }
    }
}

struct TextView: View {
    @Binding var data: [TextContent]
    @Binding var showAlert: Bool
    @Binding var alertMessage: String

    var body: some View {
        VStack(spacing: 0) {
            ForEach(data) { item in
                VStack(spacing: 20) {
                    Text(item.question)
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 70)

                    Button(action: { checkAnswer(selected: item.answer1, correct: item.correct) }) {
                        Text(item.answer1)
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                    Button(action: { checkAnswer(selected: item.answer2, correct: item.correct) }) {
                        Text(item.answer2)
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                    Button(action: { checkAnswer(selected: item.answer3, correct: item.correct) }) {
                        Text(item.answer3)
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                    Button(action: { checkAnswer(selected: item.answer4, correct: item.correct) }) {
                        Text(item.answer4)
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                }
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                .background(Color.black)
            }
        }
    }

    func checkAnswer(selected: String, correct: String) {
        if selected == correct {
            alertMessage = "정답입니다!"
        } else {
            alertMessage = "틀렸습니다."
        }
        showAlert = true
    }
}

#Preview {
    shortsView()
}
