//
//  SettingView.swift
//  QQ
//
//  Created by 구민규 on 5/10/24.
//

import SwiftUI

struct SettingView: View {
    @State private var selection = 0
    var body: some View {
        VStack{
            Picker("select type",selection: $selection){
                
                Text("전체 선택").tag(0)
                Text("랜덤 선택").tag(1)
            }.foregroundColor(.black)
                .pickerStyle(.segmented)
            
            MultiplePicker()
            
            Button(action: {
                
                
                print(selection)
            }, label: {
                RoundedRectangle(cornerRadius: 10)
                    .frame(height: 60)
                    .overlay(
                    Text("저장")
                        .font(.system(size: 18))
                        .fontWeight(.bold)
                        .foregroundStyle(Color.white)
                    )
            })
            .padding()
            
            
            
            
        }.padding()
    }
}

#Preview {
    SettingView()
}
