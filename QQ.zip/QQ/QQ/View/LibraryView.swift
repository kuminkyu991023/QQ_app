//
//  LibraryView.swift
//  QQ
//
//  Created by 구민규 on 5/9/24.
//

import SwiftUI

struct LibraryView: View {
    @State private var showingConFirm = false
    @State private var makingCategoryView = false
    @State private var UploadingFileView = false
    
    var body: some View {
        NavigationStack{
            
            Form{
                Section{
                   
                        
                           
                            
                            VStack(alignment:.leading,spacing:7){
                                Text("AI 활용표현과 문제해결").font(.system(size: 32).bold())
                                Text("2023-04-23").font(.system(size: 14))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.gray)
                                
                            }
                        .padding(10)
                        .background(NavigationLink("",destination: LibraryDetailView()).opacity(0))
                    
                }
                Section{
                   
                      
                            //RoundedRectangle(cornerRadius: 24)
                              //  .fill(Color("color2"))
                                //.frame(width:72,height:72)
                            
                            VStack(alignment:.leading,spacing:7){
                                Text("토익").font(.system(size: 32).bold())
                                Text("2023-01-23").font(.system(size: 14))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.gray)
                                
                            }
                        .padding(10)
                        .background(NavigationLink("",destination: LibraryDetailView()).opacity(0))
                    
                }
                Section{
                   
                        
                            
                            
                            VStack(alignment:.leading,spacing: 7){
                                Text("동남아 역사").font(.system(size: 32).bold())
                                Text("2023-10-23").font(.system(size: 14))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.gray)
                                
                            }
                        .padding(10)
                        .background(NavigationLink("",destination: LibraryDetailView()).opacity(0))
                    
                }
                Section{
                   
                      
                           // RoundedRectangle(cornerRadius: 24)
                             //   .fill(Color("color4"))
                               // .frame(width:72,height:72)
                            
                            VStack(alignment:.leading,spacing: 7){
                                Text("역사와 리더쉽").font(.system(size: 32).bold())
                                Text("2023-02-23").font(.system(size: 14))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.gray)
                                
                            }
                        .padding(10)
                        .background(NavigationLink("",destination: LibraryDetailView()).opacity(0))
                    
                }
                Section{
                   
                      
                           
                            
                            VStack(alignment:.leading,spacing:7){
                                Text("이산수학").font(.system(size: 32).bold())
                                Text("2023-04-23").font(.system(size: 14))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.gray)
                                
                            }
                        .padding(10)
                        .background(NavigationLink("",destination: LibraryDetailView()).opacity(0))
                    
                }
                .sheet(isPresented: $makingCategoryView){
                    MakingCategoryView(makingCategoryView:$makingCategoryView)
                }
                
                .fullScreenCover(isPresented: $UploadingFileView){
                    QQ.UploadingFileView(UploadingFileView: $UploadingFileView)
                    
                }
                    
                
               
                
                
            }
            
            .navigationTitle("라이브러리")
            .scrollIndicators(.hidden)
            .toolbar{
                ToolbarItem(placement: .topBarTrailing){
                    Button(action: {showingConFirm.toggle()}, label: {
                        Image(systemName:"plus")
                            .foregroundColor(.black)
                    })
                }
                
            }
        }.confirmationDialog("", isPresented: $showingConFirm){
            Button(action: {
                makingCategoryView.toggle()
                
            }, label: {
                Text("카테고리 추가")
            })
            Button(action: {
                UploadingFileView.toggle()
            }, label: {
                Text("파일 업로드")
            })
            
        }
    }
}

#Preview {
    LibraryView()
}
