//
//  RefactoryView.swift
//  QQ
//
//  Created by 구민규 on 5/10/24.
//

import SwiftUI

struct RefactoryView: View {
    @State private var nameChange = "hello world"
    var body: some View {
        NavigationStack{
            Form{
                TextField("", text: $nameChange)
            }.toolbar{
                
                ToolbarItem(placement: .topBarLeading){
                    
                    Button(action: {
                                print("수정을 취소합니다.")
                        
                    }, label: {
                        Text("취소")
                    })
                }
                
                ToolbarItem(placement: .topBarTrailing){
                    
                    Button(action: {
                            print("수정 저장")
                        
                    }, label: {
                        Text("저장")
                    })
                }
            }
            
        }
    }
}

#Preview {
    RefactoryView()
}
