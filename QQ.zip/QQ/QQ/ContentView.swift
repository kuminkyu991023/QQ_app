//
//  ContentView.swift
//  QQ
//
//  Created by 구민규 on 4/9/24.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        TabView{
            
            NavigationStack{
                HomeView()
                .scrollIndicators(.hidden)
                .navigationTitle("요약")
            }
            .tabItem { Image(systemName: "house")
            Text("홈")}
            
            
            LibraryView()
                .tabItem { Image(systemName: "folder")
                Text("라이브러리")}
            shortsView()
                .tabItem{
                    Image(systemName: "play.circle")
                    Text("shorts")
                }
            SettingView()
                .tabItem{
                    Image(systemName: "gearshape")
                    Text("설정")
                }
        }
    }
}

#Preview {
    ContentView()
}
