//
//  QQApp.swift
//  QQ
//
//  Created by 구민규 on 4/9/24.
//

import SwiftUI
import SwiftData
@main
struct QQApp: App {
    var body: some Scene {
        WindowGroup {
           ContentView()
                .modelContainer(for: QuestionData.self)
        }
    }
}
